/// <reference path="../.astro/types.d.ts" />
/// <reference types="astro/client" />
