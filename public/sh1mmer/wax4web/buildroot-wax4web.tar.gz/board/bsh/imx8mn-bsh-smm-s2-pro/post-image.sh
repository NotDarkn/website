#!/bin/sh

support/scripts/genimage.sh -c ${BINARIES_DIR}/genimage.cfg
